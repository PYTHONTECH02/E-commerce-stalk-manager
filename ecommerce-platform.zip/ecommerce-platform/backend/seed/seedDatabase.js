require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../src/models/User');
const Product = require('../src/models/Product');
const { connectDB } = require('../src/utils/database');

// Connect to database
connectDB();

const seedDatabase = async () => {
  try {
    // Clear existing data
    await User.deleteMany({});
    await Product.deleteMany({});
    
    console.log('🗑️  Existing data cleared');
    
    // Create Super Admin
    const superAdmin = await User.create({
      email: process.env.DEFAULT_SUPER_ADMIN_EMAIL || 'superadmin@example.com',
      password: process.env.DEFAULT_SUPER_ADMIN_PASSWORD || 'SuperAdmin123!',
      fullName: 'Super Admin',
      phone: '+1234567890',
      role: 'super_admin',
      permissions: [
        'manage_users',
        'view_analytics',
        'manage_products',
        'process_orders',
        'manage_inventory',
        'manage_payments'
      ]
    });
    
    console.log('👑 Super Admin created:', superAdmin.email);
    
    // Create Admin
    const admin = await User.create({
      email: 'admin@example.com',
      password: 'Admin123!',
      fullName: 'Store Admin',
      phone: '+1234567891',
      role: 'admin',
      permissions: [
        'manage_products',
        'process_orders',
        'manage_inventory',
        'view_products'
      ]
    });
    
    console.log('👨‍💼 Admin created:', admin.email);
    
    // Create Sample Customers
    const customers = await User.create([
      {
        email: 'customer1@example.com',
        password: 'Customer123!',
        fullName: 'John Doe',
        phone: '+1234567892',
        role: 'customer'
      },
      {
        email: 'customer2@example.com',
        password: 'Customer123!',
        fullName: 'Jane Smith',
        phone: '+1234567893',
        role: 'customer'
      }
    ]);
    
    console.log(`👥 ${customers.length} customers created`);
    
    // Create Sample Products
    const sampleProducts = [
      {
        name: 'Wireless Bluetooth Headphones',
        description: 'High-quality wireless headphones with noise cancellation',
        price: 99.99,
        costPrice: 49.99,
        category: 'electronics',
        stockQuantity: 50,
        sku: 'ELC-WBH-1001',
        minStockLevel: 10,
        addedBy: admin._id,
        tags: ['electronics', 'audio', 'wireless']
      },
      {
        name: 'Smart Watch Pro',
        description: 'Feature-rich smartwatch with fitness tracking',
        price: 199.99,
        costPrice: 99.99,
        category: 'electronics',
        stockQuantity: 25,
        sku: 'ELC-SWP-1002',
        minStockLevel: 5,
        addedBy: admin._id,
        tags: ['electronics', 'wearable', 'fitness']
      },
      {
        name: 'Cotton T-Shirt',
        description: 'Premium cotton t-shirt for everyday wear',
        price: 24.99,
        costPrice: 9.99,
        category: 'clothing',
        stockQuantity: 100,
        sku: 'CLO-TSH-2001',
        minStockLevel: 20,
        addedBy: admin._id,
        tags: ['clothing', 'casual', 'cotton']
      },
      {
        name: 'Kitchen Blender',
        description: 'High-power blender for smoothies and food processing',
        price: 79.99,
        costPrice: 39.99,
        category: 'home & kitchen',
        stockQuantity: 30,
        sku: 'HOM-BLD-3001',
        minStockLevel: 5,
        addedBy: admin._id,
        tags: ['kitchen', 'appliance', 'blender']
      },
      {
        name: 'Running Shoes',
        description: 'Lightweight running shoes with cushioning',
        price: 89.99,
        costPrice: 44.99,
        category: 'sports',
        stockQuantity: 40,
        sku: 'SPT-RSH-4001',
        minStockLevel: 8,
        addedBy: admin._id,
        tags: ['sports', 'footwear', 'running']
      }
    ];
    
    const products = await Product.create(sampleProducts);
    console.log(`📦 ${products.length} sample products created`);
    
    console.log('✅ Database seeded successfully!');
    console.log('\n🔑 Login Credentials:');
    console.log('Super Admin:', superAdmin.email, '/', process.env.DEFAULT_SUPER_ADMIN_PASSWORD || 'SuperAdmin123!');
    console.log('Admin:', admin.email, '/', 'Admin123!');
    console.log('Customer:', customers[0].email, '/', 'Customer123!');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
};

// Run seed
seedDatabase();