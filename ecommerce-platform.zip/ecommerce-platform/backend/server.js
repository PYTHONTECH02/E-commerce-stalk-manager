require('dotenv').config();
const app = require('./src/app');
const { connectDB } = require('./src/utils/database');

const PORT = process.env.PORT || 5000;

// Connect to database
connectDB()
  .then(() => {
    console.log('✅ Database connected successfully');
    
    // Start server
    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`📊 Super Admin: http://localhost:${PORT}/super-admin`);
      console.log(`👨‍💼 Admin: http://localhost:${PORT}/admin`);
      console.log(`🛍️ Customer: http://localhost:${PORT}/customer`);
    });
  })
  .catch((error) => {
    console.error('❌ Database connection failed:', error);
    process.exit(1);
  });