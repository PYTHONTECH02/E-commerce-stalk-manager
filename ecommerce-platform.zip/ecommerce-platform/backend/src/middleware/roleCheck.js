const roleMiddleware = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Not authenticated'
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Access denied. Required role: ${roles.join(' or ')}`
      });
    }

    next();
  };
};

// Specific role middlewares
const isSuperAdmin = roleMiddleware('super_admin');
const isAdmin = roleMiddleware('admin', 'super_admin');
const isCustomer = roleMiddleware('customer', 'admin', 'super_admin');

module.exports = {
  roleMiddleware,
  isSuperAdmin,
  isAdmin,
  isCustomer
};