// Generate random string
exports.generateRandomString = (length = 10) => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

// Format currency
exports.formatCurrency = (amount, currency = 'USD') => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency
  }).format(amount);
};

// Calculate profit margin
exports.calculateProfitMargin = (costPrice, sellingPrice) => {
  if (costPrice === 0) return 0;
  return ((sellingPrice - costPrice) / costPrice * 100).toFixed(2);
};

// Generate SKU
exports.generateSKU = (productName, category) => {
  const prefix = category.substring(0, 3).toUpperCase();
  const nameCode = productName.substring(0, 3).toUpperCase();
  const random = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}-${nameCode}-${random}`;
};

// Validate phone number (simple validation)
exports.validatePhoneNumber = (phone) => {
  const phoneRegex = /^\+?[1-9]\d{1,14}$/;
  return phoneRegex.test(phone);
};

// Calculate order totals
exports.calculateOrderTotals = (items, taxRate = 0.1, shipping = 0) => {
  const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * taxRate;
  const total = subtotal + tax + shipping;
  
  return {
    subtotal,
    tax,
    shipping,
    total
  };
};