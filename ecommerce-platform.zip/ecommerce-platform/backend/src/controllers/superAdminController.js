const User = require('../models/User');
const Order = require('../models/Order');
const Product = require('../models/Product');
const Payment = require('../models/Payment');

// @desc    Get dashboard statistics
// @route   GET /api/super-admin/dashboard
// @access  Private/SuperAdmin
exports.getDashboardStats = async (req, res) => {
  try {
    // Get counts
    const totalUsers = await User.countDocuments();
    const totalAdmins = await User.countDocuments({ role: 'admin' });
    const totalCustomers = await User.countDocuments({ role: 'customer' });
    
    const totalProducts = await Product.countDocuments();
    const totalOrders = await Order.countDocuments();
    
    // Get revenue statistics
    const revenueResult = await Order.aggregate([
      {
        $match: {
          paymentStatus: 'paid',
          status: { $ne: 'cancelled' }
        }
      },
      {
        $group: {
          _id: null,
          totalRevenue: { $sum: '$totalAmount' },
          averageOrderValue: { $avg: '$totalAmount' }
        }
      }
    ]);
    
    // Get today's orders
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayOrders = await Order.countDocuments({
      createdAt: { $gte: today }
    });
    
    // Get low stock products
    const lowStockProducts = await Product.countDocuments({
      $expr: { $lte: ['$stockQuantity', '$minStockLevel'] }
    });
    
    // Get recent orders
    const recentOrders = await Order.find()
      .sort({ createdAt: -1 })
      .limit(10)
      .populate('customer', 'fullName email phone')
      .select('orderNumber totalAmount status createdAt');
    
    res.status(200).json({
      success: true,
      data: {
        counts: {
          totalUsers,
          totalAdmins,
          totalCustomers,
          totalProducts,
          totalOrders,
          todayOrders,
          lowStockProducts
        },
        revenue: revenueResult[0] || { totalRevenue: 0, averageOrderValue: 0 },
        recentOrders
      }
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get analytics data
// @route   GET /api/super-admin/analytics
// @access  Private/SuperAdmin
exports.getAnalytics = async (req, res) => {
  try {
    const { period = 'month' } = req.query;
    
    // Calculate date range based on period
    const endDate = new Date();
    let startDate = new Date();
    
    switch (period) {
      case 'week':
        startDate.setDate(startDate.getDate() - 7);
        break;
      case 'month':
        startDate.setMonth(startDate.getMonth() - 1);
        break;
      case 'quarter':
        startDate.setMonth(startDate.getMonth() - 3);
        break;
      case 'year':
        startDate.setFullYear(startDate.getFullYear() - 1);
        break;
      default:
        startDate.setMonth(startDate.getMonth() - 1);
    }
    
    // Sales trend
    const salesTrend = await Order.aggregate([
      {
        $match: {
          createdAt: { $gte: startDate, $lte: endDate },
          paymentStatus: 'paid'
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: '%Y-%m-%d', date: '$createdAt' }
          },
          totalSales: { $sum: '$totalAmount' },
          orderCount: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);
    
    // Top products
    const topProducts = await Order.aggregate([
      {
        $match: {
          createdAt: { $gte: startDate, $lte: endDate }
        }
      },
      { $unwind: '$items' },
      {
        $group: {
          _id: '$items.product',
          totalQuantity: { $sum: '$items.quantity' },
          totalRevenue: { $sum: '$items.total' }
        }
      },
      { $sort: { totalQuantity: -1 } },
      { $limit: 10 }
    ]);
    
    // Populate product details
    const productIds = topProducts.map(item => item._id);
    const products = await Product.find({ _id: { $in: productIds } });
    
    const topProductsWithDetails = topProducts.map(item => {
      const product = products.find(p => p._id.toString() === item._id.toString());
      return {
        product: product ? {
          name: product.name,
          sku: product.sku,
          category: product.category
        } : null,
        totalQuantity: item.totalQuantity,
        totalRevenue: item.totalRevenue
      };
    });
    
    // Customer statistics
    const customerStats = await Order.aggregate([
      {
        $match: {
          createdAt: { $gte: startDate, $lte: endDate }
        }
      },
      {
        $group: {
          _id: '$customer',
          totalOrders: { $sum: 1 },
          totalSpent: { $sum: '$totalAmount' }
        }
      },
      {
        $group: {
          _id: null,
          avgOrdersPerCustomer: { $avg: '$totalOrders' },
          avgSpentPerCustomer: { $avg: '$totalSpent' },
          totalCustomers: { $sum: 1 }
        }
      }
    ]);
    
    res.status(200).json({
      success: true,
      data: {
        period,
        startDate,
        endDate,
        salesTrend,
        topProducts: topProductsWithDetails,
        customerStats: customerStats[0] || {
          avgOrdersPerCustomer: 0,
          avgSpentPerCustomer: 0,
          totalCustomers: 0
        }
      }
    });
  } catch (error) {
    console.error('Analytics error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Create new admin
// @route   POST /api/super-admin/admins
// @access  Private/SuperAdmin
exports.createAdmin = async (req, res) => {
  try {
    const { email, password, phone, fullName } = req.body;
    
    // Check if user exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User already exists'
      });
    }
    
    // Create admin user
    const admin = await User.create({
      email,
      password,
      phone,
      fullName,
      role: 'admin',
      permissions: [
        'manage_products',
        'process_orders',
        'manage_inventory',
        'view_products'
      ]
    });
    
    res.status(201).json({
      success: true,
      data: {
        id: admin._id,
        email: admin.email,
        fullName: admin.fullName,
        phone: admin.phone,
        role: admin.role
      }
    });
  } catch (error) {
    console.error('Create admin error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get all admins
// @route   GET /api/super-admin/admins
// @access  Private/SuperAdmin
exports.getAllAdmins = async (req, res) => {
  try {
    const admins = await User.find({ role: 'admin' })
      .select('-password')
      .sort({ createdAt: -1 });
    
    res.status(200).json({
      success: true,
      count: admins.length,
      data: admins
    });
  } catch (error) {
    console.error('Get admins error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get all users
// @route   GET /api/super-admin/users
// @access  Private/SuperAdmin
exports.getAllUsers = async (req, res) => {
  try {
    const { role, search, page = 1, limit = 20 } = req.query;
    
    const query = {};
    
    if (role) {
      query.role = role;
    }
    
    if (search) {
      query.$or = [
        { email: { $regex: search, $options: 'i' } },
        { fullName: { $regex: search, $options: 'i' } },
        { phone: { $regex: search, $options: 'i' } }
      ];
    }
    
    const skip = (page - 1) * limit;
    
    const users = await User.find(query)
      .select('-password')
      .skip(skip)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });
    
    const total = await User.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: users.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: users
    });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Update user status
// @route   PUT /api/super-admin/users/:id/status
// @access  Private/SuperAdmin
exports.updateUserStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { isActive } = req.body;
    
    const user = await User.findById(id);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }
    
    // Cannot deactivate super admin
    if (user.role === 'super_admin' && req.user.id !== user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Cannot modify another super admin'
      });
    }
    
    user.isActive = isActive;
    await user.save();
    
    res.status(200).json({
      success: true,
      message: `User ${isActive ? 'activated' : 'deactivated'} successfully`,
      data: {
        id: user._id,
        email: user.email,
        isActive: user.isActive
      }
    });
  } catch (error) {
    console.error('Update user status error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get inventory report
// @route   GET /api/super-admin/inventory-report
// @access  Private/SuperAdmin
exports.getInventoryReport = async (req, res) => {
  try {
    const { category, lowStockOnly } = req.query;
    
    const query = {};
    
    if (category) {
      query.category = category;
    }
    
    if (lowStockOnly === 'true') {
      query.$expr = { $lte: ['$stockQuantity', '$minStockLevel'] };
    }
    
    const products = await Product.find(query)
      .populate('addedBy', 'fullName email')
      .sort({ stockQuantity: 1 });
    
    // Calculate inventory value
    const inventoryValue = products.reduce((total, product) => {
      return total + (product.costPrice * product.stockQuantity);
    }, 0);
    
    // Calculate retail value
    const retailValue = products.reduce((total, product) => {
      return total + (product.price * product.stockQuantity);
    }, 0);
    
    res.status(200).json({
      success: true,
      data: {
        products,
        summary: {
          totalProducts: products.length,
          inventoryValue,
          retailValue,
          potentialProfit: retailValue - inventoryValue,
          lowStockItems: products.filter(p => p.stockQuantity <= p.minStockLevel).length,
          outOfStockItems: products.filter(p => p.stockQuantity === 0).length
        }
      }
    });
  } catch (error) {
    console.error('Inventory report error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get financial report
// @route   GET /api/super-admin/financial-report
// @access  Private/SuperAdmin
exports.getFinancialReport = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    const query = { paymentStatus: 'paid' };
    
    if (startDate && endDate) {
      query.createdAt = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }
    
    // Get all paid orders
    const orders = await Order.find(query).populate('customer', 'fullName email');
    
    // Calculate totals
    const totals = orders.reduce(
      (acc, order) => {
        acc.totalRevenue += order.totalAmount;
        acc.totalOrders += 1;
        acc.totalItems += order.items.reduce((sum, item) => sum + item.quantity, 0);
        return acc;
      },
      { totalRevenue: 0, totalOrders: 0, totalItems: 0 }
    );
    
    // Get payment method breakdown
    const paymentMethods = orders.reduce((acc, order) => {
      const method = order.paymentMethod;
      acc[method] = (acc[method] || 0) + order.totalAmount;
      return acc;
    }, {});
    
    // Get product costs for profit calculation
    const productIds = [...new Set(
      orders.flatMap(order => order.items.map(item => item.product.toString()))
    )];
    
    const products = await Product.find({ _id: { $in: productIds } });
    
    // Calculate profit
    let totalCost = 0;
    orders.forEach(order => {
      order.items.forEach(item => {
        const product = products.find(p => p._id.toString() === item.product.toString());
        if (product) {
          totalCost += product.costPrice * item.quantity;
        }
      });
    });
    
    const totalProfit = totals.totalRevenue - totalCost;
    const profitMargin = totals.totalRevenue > 0 ? (totalProfit / totals.totalRevenue * 100) : 0;
    
    res.status(200).json({
      success: true,
      data: {
        period: {
          startDate: startDate || 'All time',
          endDate: endDate || 'Present'
        },
        totals: {
          ...totals,
          totalCost,
          totalProfit,
          profitMargin: profitMargin.toFixed(2)
        },
        paymentMethods,
        orders: orders.slice(0, 50) // Return recent 50 orders
      }
    });
  } catch (error) {
    console.error('Financial report error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};