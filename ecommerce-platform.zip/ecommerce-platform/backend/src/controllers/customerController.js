const Product = require('../models/Product');
const Order = require('../models/Order');
const User = require('../models/User');

// @desc    Get all products for customers
// @route   GET /api/customer/products
// @access  Private/Customer
exports.getAllProducts = async (req, res) => {
  try {
    const {
      category,
      search,
      minPrice,
      maxPrice,
      sortBy = 'createdAt',
      sortOrder = 'desc',
      page = 1,
      limit = 12
    } = req.query;
    
    const query = { isActive: true, stockQuantity: { $gt: 0 } };
    
    if (category) {
      query.category = category;
    }
    
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { tags: { $regex: search, $options: 'i' } }
      ];
    }
    
    if (minPrice) {
      query.price = { $gte: parseFloat(minPrice) };
    }
    
    if (maxPrice) {
      query.price = query.price || {};
      query.price.$lte = parseFloat(maxPrice);
    }
    
    const skip = (page - 1) * limit;
    const sort = { [sortBy]: sortOrder === 'desc' ? -1 : 1 };
    
    const products = await Product.find(query)
      .select('-costPrice -addedBy -supplier')
      .skip(skip)
      .limit(parseInt(limit))
      .sort(sort);
    
    const total = await Product.countDocuments(query);
    
    // Get categories for filtering
    const categories = await Product.distinct('category', { isActive: true });
    
    res.status(200).json({
      success: true,
      count: products.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      categories,
      data: products
    });
  } catch (error) {
    console.error('Get customer products error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get product details
// @route   GET /api/customer/products/:id
// @access  Private/Customer
exports.getProductDetails = async (req, res) => {
  try {
    const { id } = req.params;
    
    const product = await Product.findOne({
      _id: id,
      isActive: true
    }).select('-costPrice -addedBy -supplier');
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
    
    // Get related products
    const relatedProducts = await Product.find({
      _id: { $ne: id },
      category: product.category,
      isActive: true,
      stockQuantity: { $gt: 0 }
    })
    .limit(4)
    .select('name price images stockQuantity');
    
    res.status(200).json({
      success: true,
      data: {
        product,
        relatedProducts
      }
    });
  } catch (error) {
    console.error('Get product details error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Create order
// @route   POST /api/customer/orders
// @access  Private/Customer
exports.createOrder = async (req, res) => {
  try {
    const {
      items,
      shippingAddress,
      paymentMethod,
      mobileMoneyDetails,
      notes
    } = req.body;
    
    if (!items || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No items in cart'
      });
    }
    
    // Calculate totals and validate products
    let subtotal = 0;
    const orderItems = [];
    
    for (const item of items) {
      const product = await Product.findById(item.productId);
      
      if (!product || !product.isActive) {
        return res.status(400).json({
          success: false,
          message: `Product ${item.productId} not found or unavailable`
        });
      }
      
      if (product.stockQuantity < item.quantity) {
        return res.status(400).json({
          success: false,
          message: `Insufficient stock for ${product.name}. Available: ${product.stockQuantity}`
        });
      }
      
      const itemTotal = product.price * item.quantity;
      subtotal += itemTotal;
      
      orderItems.push({
        product: product._id,
        quantity: item.quantity,
        priceAtPurchase: product.price,
        total: itemTotal
      });
    }
    
    // Calculate shipping (example: free shipping over $50)
    const shipping = subtotal > 50 ? 0 : 5.99;
    
    // Calculate tax (example: 10% tax)
    const tax = subtotal * 0.1;
    
    // Calculate total
    const totalAmount = subtotal + shipping + tax;
    
    // Create order
    const order = await Order.create({
      customer: req.user.id,
      items: orderItems,
      subtotal,
      shipping,
      tax,
      totalAmount,
      shippingAddress,
      paymentMethod,
      mobileMoneyDetails: paymentMethod === 'mobile_money' ? mobileMoneyDetails : undefined,
      notes,
      status: 'pending',
      paymentStatus: 'pending'
    });
    
    // For mobile money, we'll verify payment later
    // For cash on delivery, mark as confirmed
    if (paymentMethod === 'cash_on_delivery') {
      order.status = 'confirmed';
      await order.save();
    }
    
    res.status(201).json({
      success: true,
      data: order,
      message: paymentMethod === 'mobile_money' 
        ? 'Order created. Please complete mobile money payment.'
        : 'Order created successfully.'
    });
  } catch (error) {
    console.error('Create order error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get customer orders
// @route   GET /api/customer/orders
// @access  Private/Customer
exports.getCustomerOrders = async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    
    const query = { customer: req.user.id };
    
    if (status) {
      query.status = status;
    }
    
    const skip = (page - 1) * limit;
    
    const orders = await Order.find(query)
      .populate('items.product', 'name images')
      .skip(skip)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });
    
    const total = await Order.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: orders.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: orders
    });
  } catch (error) {
    console.error('Get customer orders error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get order details
// @route   GET /api/customer/orders/:id
// @access  Private/Customer
exports.getOrderDetails = async (req, res) => {
  try {
    const { id } = req.params;
    
    const order = await Order.findOne({
      _id: id,
      customer: req.user.id
    })
    .populate('items.product', 'name sku price images')
    .populate('processedBy', 'fullName');
    
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: order
    });
  } catch (error) {
    console.error('Get order details error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Cancel order
// @route   PUT /api/customer/orders/:id/cancel
// @access  Private/Customer
exports.cancelOrder = async (req, res) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    
    const order = await Order.findOne({
      _id: id,
      customer: req.user.id
    });
    
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }
    
    // Only allow cancellation if order is pending or confirmed
    if (!['pending', 'confirmed'].includes(order.status)) {
      return res.status(400).json({
        success: false,
        message: `Cannot cancel order with status: ${order.status}`
      });
    }
    
    // Update order
    order.status = 'cancelled';
    order.cancelledAt = new Date();
    order.notes = reason ? `Cancelled by customer: ${reason}` : 'Cancelled by customer';
    
    // If paid, mark for refund
    if (order.paymentStatus === 'paid') {
      order.paymentStatus = 'refunded';
    }
    
    await order.save();
    
    res.status(200).json({
      success: true,
      message: 'Order cancelled successfully'
    });
  } catch (error) {
    console.error('Cancel order error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Update customer profile
// @route   PUT /api/customer/profile
// @access  Private/Customer
exports.updateProfile = async (req, res) => {
  try {
    const { fullName, phone, shippingAddress } = req.body;
    
    const user = await User.findById(req.user.id);
    
    if (fullName) user.fullName = fullName;
    if (phone) user.phone = phone;
    
    // Store shipping address in user if you have that field
    // Or keep it separate per order
    
    await user.save();
    
    res.status(200).json({
      success: true,
      data: {
        id: user._id,
        email: user.email,
        fullName: user.fullName,
        phone: user.phone
      }
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get customer dashboard
// @route   GET /api/customer/dashboard
// @access  Private/Customer
exports.getCustomerDashboard = async (req, res) => {
  try {
    const customerId = req.user.id;
    
    // Get order counts
    const orderCounts = await Order.aggregate([
      {
        $match: { customer: customerId }
      },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);
    
    // Get total spent
    const totalSpentResult = await Order.aggregate([
      {
        $match: { 
          customer: customerId,
          paymentStatus: 'paid'
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$totalAmount' }
        }
      }
    ]);
    
    // Get recent orders
    const recentOrders = await Order.find({ customer: customerId })
      .sort({ createdAt: -1 })
      .limit(5)
      .select('orderNumber totalAmount status createdAt');
    
    res.status(200).json({
      success: true,
      data: {
        orderCounts,
        totalSpent: totalSpentResult[0]?.total || 0,
        recentOrders
      }
    });
  } catch (error) {
    console.error('Customer dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};