const Product = require('../models/Product');
const Order = require('../models/Order');
const InventoryLog = require('../models/InventoryLog');
const User = require('../models/User');

// @desc    Get admin dashboard
// @route   GET /api/admin/dashboard
// @access  Private/Admin
exports.getAdminDashboard = async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Today's orders
    const todayOrders = await Order.countDocuments({
      createdAt: { $gte: today }
    });
    
    // Today's revenue
    const todayRevenueResult = await Order.aggregate([
      {
        $match: {
          createdAt: { $gte: today },
          paymentStatus: 'paid'
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$totalAmount' }
        }
      }
    ]);
    
    const todayRevenue = todayRevenueResult[0]?.total || 0;
    
    // Pending orders
    const pendingOrders = await Order.countDocuments({
      status: { $in: ['pending', 'confirmed', 'processing'] }
    });
    
    // Low stock products
    const lowStockProducts = await Product.countDocuments({
      $expr: { $lte: ['$stockQuantity', '$minStockLevel'] }
    });
    
    // Recent orders
    const recentOrders = await Order.find()
      .sort({ createdAt: -1 })
      .limit(10)
      .populate('customer', 'fullName email')
      .select('orderNumber totalAmount status createdAt');
    
    // Recent products added
    const recentProducts = await Product.find()
      .sort({ createdAt: -1 })
      .limit(10)
      .select('name price stockQuantity category');
    
    res.status(200).json({
      success: true,
      data: {
        stats: {
          todayOrders,
          todayRevenue,
          pendingOrders,
          lowStockProducts
        },
        recentOrders,
        recentProducts
      }
    });
  } catch (error) {
    console.error('Admin dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Add new product
// @route   POST /api/admin/products
// @access  Private/Admin
exports.addProduct = async (req, res) => {
  try {
    const {
      name,
      description,
      price,
      costPrice,
      category,
      stockQuantity,
      sku,
      minStockLevel,
      supplier
    } = req.body;
    
    // Check if SKU exists
    const existingProduct = await Product.findOne({ sku: sku.toUpperCase() });
    if (existingProduct) {
      return res.status(400).json({
        success: false,
        message: 'Product with this SKU already exists'
      });
    }
    
    // Create product
    const product = await Product.create({
      name,
      description,
      price: parseFloat(price),
      costPrice: parseFloat(costPrice),
      category,
      stockQuantity: parseInt(stockQuantity) || 0,
      sku: sku.toUpperCase(),
      minStockLevel: parseInt(minStockLevel) || 5,
      addedBy: req.user.id,
      supplier: supplier || {}
    });
    
    // Create inventory log for initial stock
    await InventoryLog.create({
      product: product._id,
      changeType: 'purchase',
      quantityChange: product.stockQuantity,
      previousQuantity: 0,
      newQuantity: product.stockQuantity,
      performedBy: req.user.id,
      costPerUnit: product.costPrice,
      totalCost: product.costPrice * product.stockQuantity,
      notes: 'Initial stock addition'
    });
    
    res.status(201).json({
      success: true,
      data: product
    });
  } catch (error) {
    console.error('Add product error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get all products
// @route   GET /api/admin/products
// @access  Private/Admin
exports.getAllProducts = async (req, res) => {
  try {
    const {
      category,
      search,
      minPrice,
      maxPrice,
      lowStock,
      page = 1,
      limit = 20
    } = req.query;
    
    const query = { isActive: true };
    
    if (category) {
      query.category = category;
    }
    
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { sku: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }
    
    if (minPrice) {
      query.price = { $gte: parseFloat(minPrice) };
    }
    
    if (maxPrice) {
      query.price = query.price || {};
      query.price.$lte = parseFloat(maxPrice);
    }
    
    if (lowStock === 'true') {
      query.$expr = { $lte: ['$stockQuantity', '$minStockLevel'] };
    }
    
    const skip = (page - 1) * limit;
    
    const products = await Product.find(query)
      .populate('addedBy', 'fullName email')
      .skip(skip)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });
    
    const total = await Product.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: products.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: products
    });
  } catch (error) {
    console.error('Get products error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Update product
// @route   PUT /api/admin/products/:id
// @access  Private/Admin
exports.updateProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;
    
    const product = await Product.findById(id);
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
    
    // If stock quantity is being updated, create inventory log
    if (updateData.stockQuantity !== undefined) {
      const newQuantity = parseInt(updateData.stockQuantity);
      const quantityChange = newQuantity - product.stockQuantity;
      
      if (quantityChange !== 0) {
        await InventoryLog.create({
          product: product._id,
          changeType: quantityChange > 0 ? 'purchase' : 'adjustment',
          quantityChange: Math.abs(quantityChange),
          previousQuantity: product.stockQuantity,
          newQuantity,
          performedBy: req.user.id,
          costPerUnit: product.costPrice,
          totalCost: product.costPrice * Math.abs(quantityChange),
          notes: updateData.notes || 'Stock adjustment'
        });
      }
    }
    
    // Update product
    Object.keys(updateData).forEach(key => {
      if (key !== 'notes') {
        product[key] = updateData[key];
      }
    });
    
    await product.save();
    
    res.status(200).json({
      success: true,
      data: product
    });
  } catch (error) {
    console.error('Update product error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Delete product (soft delete)
// @route   DELETE /api/admin/products/:id
// @access  Private/Admin
exports.deleteProduct = async (req, res) => {
  try {
    const { id } = req.params;
    
    const product = await Product.findById(id);
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
    
    // Soft delete
    product.isActive = false;
    await product.save();
    
    res.status(200).json({
      success: true,
      message: 'Product deactivated successfully'
    });
  } catch (error) {
    console.error('Delete product error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Add stock to product
// @route   POST /api/admin/products/:id/add-stock
// @access  Private/Admin
exports.addStock = async (req, res) => {
  try {
    const { id } = req.params;
    const { quantity, costPerUnit, notes } = req.body;
    
    const product = await Product.findById(id);
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
    
    const addQuantity = parseInt(quantity);
    const previousQuantity = product.stockQuantity;
    const newQuantity = previousQuantity + addQuantity;
    
    // Update product stock
    product.stockQuantity = newQuantity;
    if (costPerUnit) {
      product.costPrice = parseFloat(costPerUnit);
    }
    await product.save();
    
    // Create inventory log
    await InventoryLog.create({
      product: product._id,
      changeType: 'purchase',
      quantityChange: addQuantity,
      previousQuantity,
      newQuantity,
      performedBy: req.user.id,
      costPerUnit: costPerUnit || product.costPrice,
      totalCost: (costPerUnit || product.costPrice) * addQuantity,
      notes: notes || 'Stock purchase'
    });
    
    res.status(200).json({
      success: true,
      data: {
        product,
        stockAdded: addQuantity,
        previousQuantity,
        newQuantity
      }
    });
  } catch (error) {
    console.error('Add stock error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get all orders
// @route   GET /api/admin/orders
// @access  Private/Admin
exports.getAllOrders = async (req, res) => {
  try {
    const {
      status,
      paymentStatus,
      startDate,
      endDate,
      search,
      page = 1,
      limit = 20
    } = req.query;
    
    const query = {};
    
    if (status) {
      query.status = status;
    }
    
    if (paymentStatus) {
      query.paymentStatus = paymentStatus;
    }
    
    if (startDate && endDate) {
      query.createdAt = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }
    
    if (search) {
      query.$or = [
        { orderNumber: { $regex: search, $options: 'i' } },
        { 'customer.fullName': { $regex: search, $options: 'i' } },
        { 'customer.email': { $regex: search, $options: 'i' } }
      ];
    }
    
    const skip = (page - 1) * limit;
    
    const orders = await Order.find(query)
      .populate('customer', 'fullName email phone')
      .populate('items.product', 'name sku price')
      .skip(skip)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });
    
    const total = await Order.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: orders.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: orders
    });
  } catch (error) {
    console.error('Get orders error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Update order status
// @route   PUT /api/admin/orders/:id/status
// @access  Private/Admin
exports.updateOrderStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, notes } = req.body;
    
    const order = await Order.findById(id);
    
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }
    
    // Update order status
    const oldStatus = order.status;
    order.status = status;
    order.processedBy = req.user.id;
    
    if (status === 'delivered') {
      order.deliveredAt = new Date();
    } else if (status === 'cancelled') {
      order.cancelledAt = new Date();
      
      // If cancelled and paid, refund
      if (order.paymentStatus === 'paid') {
        order.paymentStatus = 'refunded';
      }
    }
    
    // If order is being processed, reduce stock
    if (status === 'processing' && oldStatus !== 'processing') {
      for (const item of order.items) {
        const product = await Product.findById(item.product);
        if (product) {
          const previousQuantity = product.stockQuantity;
          const newQuantity = previousQuantity - item.quantity;
          
          product.stockQuantity = newQuantity;
          await product.save();
          
          // Create inventory log
          await InventoryLog.create({
            product: product._id,
            changeType: 'sale',
            quantityChange: -item.quantity,
            previousQuantity,
            newQuantity,
            order: order._id,
            performedBy: req.user.id,
            notes: `Order ${order.orderNumber}`
          });
        }
      }
    }
    
    await order.save();
    
    res.status(200).json({
      success: true,
      data: {
        order,
        statusChanged: {
          from: oldStatus,
          to: status
        }
      }
    });
  } catch (error) {
    console.error('Update order status error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get inventory logs
// @route   GET /api/admin/inventory-logs
// @access  Private/Admin
exports.getInventoryLogs = async (req, res) => {
  try {
    const {
      productId,
      changeType,
      startDate,
      endDate,
      page = 1,
      limit = 20
    } = req.query;
    
    const query = {};
    
    if (productId) {
      query.product = productId;
    }
    
    if (changeType) {
      query.changeType = changeType;
    }
    
    if (startDate && endDate) {
      query.createdAt = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }
    
    const skip = (page - 1) * limit;
    
    const logs = await InventoryLog.find(query)
      .populate('product', 'name sku')
      .populate('performedBy', 'fullName email')
      .populate('order', 'orderNumber')
      .skip(skip)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });
    
    const total = await InventoryLog.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: logs.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: logs
    });
  } catch (error) {
    console.error('Get inventory logs error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get customers
// @route   GET /api/admin/customers
// @access  Private/Admin
exports.getCustomers = async (req, res) => {
  try {
    const { search, page = 1, limit = 20 } = req.query;
    
    const query = { role: 'customer', isActive: true };
    
    if (search) {
      query.$or = [
        { email: { $regex: search, $options: 'i' } },
        { fullName: { $regex: search, $options: 'i' } },
        { phone: { $regex: search, $options: 'i' } }
      ];
    }
    
    const skip = (page - 1) * limit;
    
    const customers = await User.find(query)
      .select('-password')
      .skip(skip)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });
    
    // Get order counts for each customer
    const customerIds = customers.map(c => c._id);
    const orderCounts = await Order.aggregate([
      {
        $match: {
          customer: { $in: customerIds }
        }
      },
      {
        $group: {
          _id: '$customer',
          totalOrders: { $sum: 1 },
          totalSpent: { $sum: '$totalAmount' }
        }
      }
    ]);
    
    const customersWithStats = customers.map(customer => {
      const stats = orderCounts.find(o => o._id.toString() === customer._id.toString());
      return {
        ...customer.toObject(),
        totalOrders: stats?.totalOrders || 0,
        totalSpent: stats?.totalSpent || 0
      };
    });
    
    const total = await User.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: customers.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: customersWithStats
    });
  } catch (error) {
    console.error('Get customers error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};