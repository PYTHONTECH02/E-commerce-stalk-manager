const Order = require('../models/Order');
const Payment = require('../models/Payment');
const User = require('../models/User');

// Mobile Money providers configuration (you'll need to get actual API keys)
const MOBILE_MONEY_PROVIDERS = {
  mtn: {
    apiKey: process.env.MTN_API_KEY,
    apiUrl: 'https://api.mtn.com/v1/payments'
  },
  airtel: {
    apiKey: process.env.AIRTEL_API_KEY,
    apiUrl: 'https://api.airtel.com/payments'
  }
};

// @desc    Initiate mobile money payment
// @route   POST /api/payments/mobile-money/initiate
// @access  Private/Customer
exports.initiateMobileMoneyPayment = async (req, res) => {
  try {
    const { orderId, phoneNumber, provider } = req.body;
    
    // Find order
    const order = await Order.findOne({
      _id: orderId,
      customer: req.user.id,
      paymentMethod: 'mobile_money',
      paymentStatus: 'pending'
    });
    
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found or already paid'
      });
    }
    
    // Validate provider
    if (!MOBILE_MONEY_PROVIDERS[provider]) {
      return res.status(400).json({
        success: false,
        message: 'Unsupported mobile money provider'
      });
    }
    
    // Simulate payment initiation (replace with actual API call)
    const transactionId = `MM-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    // Update order with mobile money details
    order.mobileMoneyDetails = {
      provider,
      phoneNumber,
      transactionId,
      confirmed: false
    };
    
    await order.save();
    
    // Create payment record
    const payment = await Payment.create({
      order: order._id,
      customer: req.user.id,
      amount: order.totalAmount,
      paymentMethod: 'mobile_money',
      mobileMoneyDetails: {
        provider,
        phoneNumber,
        transactionId,
        senderName: req.user.fullName
      },
      status: 'pending',
      notes: `Mobile money payment initiated via ${provider}`
    });
    
    // In a real implementation, you would:
    // 1. Call the provider's API to initiate payment
    // 2. Save the provider's transaction ID
    // 3. Set up webhook for payment confirmation
    
    // For demo purposes, we'll simulate a successful initiation
    res.status(200).json({
      success: true,
      data: {
        orderId: order._id,
        transactionId,
        amount: order.totalAmount,
        phoneNumber,
        provider,
        instructions: `Please send ${order.totalAmount} to ${phoneNumber} via ${provider.toUpperCase()} and use ${transactionId} as reference`
      },
      message: 'Payment initiated. Please complete the transaction on your phone.'
    });
  } catch (error) {
    console.error('Initiate payment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Verify mobile money payment
// @route   POST /api/payments/mobile-money/verify
// @access  Private/Admin
exports.verifyMobileMoneyPayment = async (req, res) => {
  try {
    const { orderId, transactionId, confirmed } = req.body;
    
    // Find order
    const order = await Order.findById(orderId);
    
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }
    
    // Find payment
    const payment = await Payment.findOne({
      order: orderId,
      'mobileMoneyDetails.transactionId': transactionId
    });
    
    if (!payment) {
      return res.status(404).json({
        success: false,
        message: 'Payment record not found'
      });
    }
    
    if (confirmed) {
      // In real implementation, verify with provider's API
      // const providerConfig = MOBILE_MONEY_PROVIDERS[order.mobileMoneyDetails.provider];
      // const verification = await verifyWithProvider(transactionId, providerConfig);
      
      // For demo, we'll assume verification is successful
      const verification = { success: true, confirmed: true };
      
      if (verification.success && verification.confirmed) {
        // Update payment
        payment.status = 'completed';
        payment.confirmedBy = req.user.id;
        payment.confirmedAt = new Date();
        await payment.save();
        
        // Update order
        order.paymentStatus = 'paid';
        order.status = 'confirmed';
        order.mobileMoneyDetails.confirmed = true;
        await order.save();
        
        return res.status(200).json({
          success: true,
          message: 'Payment verified and order confirmed'
        });
      } else {
        return res.status(400).json({
          success: false,
          message: 'Payment verification failed'
        });
      }
    } else {
      // Mark payment as failed
      payment.status = 'failed';
      payment.confirmedBy = req.user.id;
      payment.confirmedAt = new Date();
      await payment.save();
      
      // Update order
      order.paymentStatus = 'failed';
      await order.save();
      
      return res.status(200).json({
        success: true,
        message: 'Payment marked as failed'
      });
    }
  } catch (error) {
    console.error('Verify payment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get payment history
// @route   GET /api/payments/history
// @access  Private
exports.getPaymentHistory = async (req, res) => {
  try {
    const { startDate, endDate, status, page = 1, limit = 20 } = req.query;
    
    const query = {};
    
    // Filter by user role
    if (req.user.role === 'customer') {
      query.customer = req.user.id;
    }
    
    if (status) {
      query.status = status;
    }
    
    if (startDate && endDate) {
      query.createdAt = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }
    
    const skip = (page - 1) * limit;
    
    const payments = await Payment.find(query)
      .populate('order', 'orderNumber totalAmount')
      .populate('customer', 'fullName email')
      .populate('confirmedBy', 'fullName')
      .skip(skip)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });
    
    const total = await Payment.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: payments.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: payments
    });
  } catch (error) {
    console.error('Get payment history error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// @desc    Get pending mobile money payments
// @route   GET /api/payments/mobile-money/pending
// @access  Private/Admin
exports.getPendingMobileMoneyPayments = async (req, res) => {
  try {
    const payments = await Payment.find({
      paymentMethod: 'mobile_money',
      status: 'pending'
    })
    .populate('order', 'orderNumber totalAmount')
    .populate('customer', 'fullName phone email')
    .sort({ createdAt: -1 });
    
    res.status(200).json({
      success: true,
      count: payments.length,
      data: payments
    });
  } catch (error) {
    console.error('Get pending payments error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// Helper function to verify with provider (placeholder)
async function verifyWithProvider(transactionId, providerConfig) {
  // This is a placeholder for actual provider API integration
  // You would make an API call to the provider to verify the transaction
  
  // Example for MTN:
  // const response = await fetch(`${providerConfig.apiUrl}/verify`, {
  //   method: 'POST',
  //   headers: {
  //     'Authorization': `Bearer ${providerConfig.apiKey}`,
  //     'Content-Type': 'application/json'
  //   },
  //   body: JSON.stringify({ transactionId })
  // });
  // return response.json();
  
  // For demo, return success
  return {
    success: true,
    confirmed: true,
    amount: 100,
    timestamp: new Date()
  };
}