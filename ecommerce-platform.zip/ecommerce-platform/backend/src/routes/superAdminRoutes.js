const express = require('express');
const router = express.Router();
const {
  getDashboardStats,
  getAnalytics,
  createAdmin,
  getAllAdmins,
  getAllUsers,
  updateUserStatus,
  getInventoryReport,
  getFinancialReport
} = require('../controllers/superAdminController');
const { protect } = require('../middleware/auth');
const { isSuperAdmin } = require('../middleware/roleCheck');

// All routes are protected and require super admin role
router.use(protect);
router.use(isSuperAdmin);

// Dashboard & Analytics
router.get('/dashboard', getDashboardStats);
router.get('/analytics', getAnalytics);

// User Management
router.post('/admins', createAdmin);
router.get('/admins', getAllAdmins);
router.get('/users', getAllUsers);
router.put('/users/:id/status', updateUserStatus);

// Reports
router.get('/inventory-report', getInventoryReport);
router.get('/financial-report', getFinancialReport);

module.exports = router;