const express = require('express');
const router = express.Router();
const {
  getAllProducts,
  getProductDetails,
  createOrder,
  getCustomerOrders,
  getOrderDetails,
  cancelOrder,
  updateProfile,
  getCustomerDashboard
} = require('../controllers/customerController');
const { protect } = require('../middleware/auth');
const { isCustomer } = require('../middleware/roleCheck');

// All routes are protected
router.use(protect);
router.use(isCustomer);

// Products
router.get('/products', getAllProducts);
router.get('/products/:id', getProductDetails);

// Orders
router.post('/orders', createOrder);
router.get('/orders', getCustomerOrders);
router.get('/orders/:id', getOrderDetails);
router.put('/orders/:id/cancel', cancelOrder);

// Profile
router.put('/profile', updateProfile);

// Dashboard
router.get('/dashboard', getCustomerDashboard);

module.exports = router;