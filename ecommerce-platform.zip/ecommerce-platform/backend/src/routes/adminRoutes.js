const express = require('express');
const router = express.Router();
const {
  getAdminDashboard,
  addProduct,
  getAllProducts,
  updateProduct,
  deleteProduct,
  addStock,
  getAllOrders,
  updateOrderStatus,
  getInventoryLogs,
  getCustomers
} = require('../controllers/adminController');
const { protect } = require('../middleware/auth');
const { isAdmin } = require('../middleware/roleCheck');

// All routes are protected and require admin role
router.use(protect);
router.use(isAdmin);

// Dashboard
router.get('/dashboard', getAdminDashboard);

// Product Management
router.post('/products', addProduct);
router.get('/products', getAllProducts);
router.put('/products/:id', updateProduct);
router.delete('/products/:id', deleteProduct);
router.post('/products/:id/add-stock', addStock);

// Order Management
router.get('/orders', getAllOrders);
router.put('/orders/:id/status', updateOrderStatus);

// Inventory
router.get('/inventory-logs', getInventoryLogs);

// Customer Management
router.get('/customers', getCustomers);

module.exports = router;