const express = require('express');
const router = express.Router();
const {
  initiateMobileMoneyPayment,
  verifyMobileMoneyPayment,
  getPaymentHistory,
  getPendingMobileMoneyPayments
} = require('../controllers/paymentController');
const { protect } = require('../middleware/auth');
const { roleMiddleware } = require('../middleware/roleCheck');

// Mobile Money Payments
router.post('/mobile-money/initiate', protect, roleMiddleware(['customer']), initiateMobileMoneyPayment);
router.post('/mobile-money/verify', protect, roleMiddleware(['admin', 'super_admin']), verifyMobileMoneyPayment);
router.get('/mobile-money/pending', protect, roleMiddleware(['admin', 'super_admin']), getPendingMobileMoneyPayments);

// Payment History
router.get('/history', protect, getPaymentHistory);

module.exports = router;